using Godot;
using System;

public class Main : Spatial
{
	private int score;
	
	private Label ScoreLabel;
	
	public Camera camera;
	
	private Godot.Vector3 campos;
	
	RigidBody player;
	
	Random r = new Random();
	float linearSpeedX = 1500f;

	private PackedScene EnemyScene = ResourceLoader.Load("res://Enemy.tscn") as PackedScene;
	public override void _Ready()
	{
		player = (RigidBody) GetNode("Player");
		
		camera = (Camera)GetNode("Camera");
		
		score = 0;
		ScoreLabel = (Label)GetNode("Control/ScoreLabel");
	}

//  // Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Input(InputEvent ev)
	{
		if(ev is InputEventKey){
			var key = (InputEventKey) ev;
			if(key.IsPressed() && key.IsAction("left"))
			{
				player.SetLinearVelocity(new Vector3( -linearSpeedX * GetProcessDeltaTime(), 0, 0));
			}else
			if(key.IsPressed() && key.IsAction("right")){
				player.SetLinearVelocity(new Vector3( linearSpeedX * GetProcessDeltaTime(), 0, 0));
			}
			else{
				player.SetLinearVelocity( new Vector3(0, 0, 0));
			}
		}    
	}
	private void _on_SpawnEnemyTimer_timeout()
{
	GD.Print("Enemy is spawned");
	score += -5;   // 1
	if(score >= 0){
	ScoreLabel.SetText(score.ToString());
	}
	
	
	Godot.RigidBody e;
	e = EnemyScene.Instance() as Godot.RigidBody;
	Godot.Vector3 pos = e.GetTranslation();
	pos.z = -500;
	pos.y = 2;
	int xRand = r.Next(-5, 5) * 5;
	pos.x = pos.x - xRand;
	e.SetTranslation(pos);
	AddChild(e);
	
	Godot.Vector3 scale = e.GetScale();
	int s = r.Next(2, 4);
	scale = scale * 3;
	e.SetScale(scale);
}
public override void _Process(float delta)
{
	campos = camera.GetTranslation();
	campos.x = player.GetTranslation().x;
	camera.SetTranslation(campos);
}
private void _on_Player_body_entered(Godot.Object body)
{
	GD.Print("-Playe collied");
	Godot.RigidBody b = body as Godot.RigidBody;
	
	if(b.IsInGroup("enemy")){
		GetTree().ReloadCurrentScene();
		}else{
			}
}

}





